def morph_clean(detections):
    print("[morphology] Cleaning detections")
    return detections
