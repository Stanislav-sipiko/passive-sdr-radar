def mti_filter(caf_matrix):
    print("[filters] Applying MTI filter")
    return caf_matrix

def fir_highpass(caf_matrix):
    return caf_matrix

def normalize(caf_matrix):
    return caf_matrix
