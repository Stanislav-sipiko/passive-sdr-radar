def update_tracks(clusters):
    print("[tracker] Updating tracks")
    return clusters
