def cfar_2d(caf_matrix):
    print("[cfar] Running CFAR detector")
    return [(10, 20), (30, 40)]

def extract_peaks(detections):
    return detections
